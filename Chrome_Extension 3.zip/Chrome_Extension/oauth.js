window.onload = function() {document.getElementById('sign-in-oa2gs').addEventListener('click', function () {
    console.log("CLICK")
    chrome.identity.getAuthToken({interactive: true}, function (token,scopes) {
        console.log(token);
        console.log(scopes)
    });
});}